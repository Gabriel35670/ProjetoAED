/* 
NOME: Gabriel Meirelles Carvalho Orlando
RA: 790728
CURSO: Ciencia da Computação
DATA: XX/XX/2021
FLAGS: -std=c99 -Wall -Werror -Werror=vla -pedantic-errors -g -lm
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0

typedef int Cont;
typedef int Chave;

typedef struct noh{

    int bal;
    Chave chave;
    Cont conteudo;
    struct noh *pai;
    struct noh *esq;
    struct noh *dir;

}Noh;

typedef Noh *Arvore;

Arvore rotacaoDir(Arvore r);
Arvore rotacaoEsq(Arvore r);

Noh *novoNOH(Chave chave,Cont conteudo);
Arvore insereAVL(Noh *r,Noh *novo,int *aumentou_altura);
Arvore inserir(Arvore r,Chave chave,Cont conteudo);

void em_ordem(Arvore r);
void pre_ordem(Arvore r);
void pos_ordem(Arvore r);

int alturaAR(Arvore r);//

int verifica(Arvore r);

Noh* busca(Arvore r, Chave chave);
Noh* maxAVL(Arvore r);
Arvore removeAVL(Arvore r,Arvore alvo,int *diminuiu_tamanho);//
Arvore TSremove(Arvore tab,Chave chave);