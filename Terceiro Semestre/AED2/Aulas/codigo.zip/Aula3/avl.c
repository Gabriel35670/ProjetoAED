#include "avl.h"


Arvore rotacaoDir(Arvore r){

    Noh *aux;

    aux = r->esq;
    r->esq = aux->dir;

    if(aux->dir != NULL)
        aux->dir->pai = r;

    aux->dir = r;
    r->pai = aux;
 //   aux->pai = NULL;

    return aux;
}

Arvore rotacaoEsq(Arvore r){

    Noh *aux;

    aux = r->dir;
    r->dir = aux->esq;

    if(aux->esq != NULL)
        aux->esq->pai = r;

    aux->esq = r;
    r->pai = aux;

   // aux->pai = NULL;

    return aux;
}

Noh *novoNOH(Chave chave,Cont conteudo){

    Noh *novo;
    novo = (Noh*)malloc(sizeof(Noh));

    novo->bal = 0;
    novo->chave = chave;
    novo->conteudo = conteudo;
    novo->pai = NULL;
    novo->esq = NULL;
    novo->dir = NULL;

    return novo;

}

Arvore insereAVL(Noh *r,Noh *novo,int *aumentou_altura){

    if(r == NULL){ //Caso 1: Subarvore está vazia, novo equivale a nova raiz

        *aumentou_altura = 1;
        return novo;
    }

    //Desce a esquerda
    if(novo->chave <= r->chave){

        r->esq = insereAVL(r->esq,novo,aumentou_altura);
        r->esq->pai = r;

        if(*aumentou_altura == 1){
            //Altura da subarvore esquerda aumentou apos a inserção

            if(r->bal == 1){//Caso 2: inseriu do lado mais baixo

                r->bal = 0;
                *aumentou_altura = 0;
            }

            else if(r->bal == 0){//Caso 3: Os dois lados tinha a mesma altura

                r->bal = -1;
                *aumentou_altura = 1;
            }

            else if(r->bal == -1){//Inseriu do lado mais alto da subarvore
            
                if(r->esq->bal == -1){ //Inseriu a esquerda do filho esquerdo

                    printf("opa");
                    r = rotacaoDir(r);
                    r->dir->bal = 0;
                }
                else{//r->esq->bal == 1, inseriu a direita do filho esquerdo

                    r->esq = rotacaoEsq(r->esq);
                    r = rotacaoDir(r);

                    if(r->bal == 0){
                        r->esq->bal = 0;
                        r->dir->bal = 0;
                    }

                    else if(r->bal == -1){
                        r->esq->bal = 0;
                        r->dir->bal = 1;
                    }

                    else{//r->bal == 1
                    
                        r->esq->bal = -1;
                        r->dir->bal = 0;
                    }
                
                }

                r->bal = 0;
                *aumentou_altura = 0;
            }
        }
    }
    //Desce a direita
    else{
        r->dir = insereAVL(r->dir,novo,aumentou_altura);
        r->dir->pai = r;

        if(*aumentou_altura == 1){//altura da subarvore direita, aumentou apos inserção

            if(r->bal == -1){//Caso 2: inseriu no lado mais baixo
                r->bal = 0;
                *aumentou_altura = 0;
            }

            else if(r->bal == 0){//Caso 3: dois lados tinham a mesma altura
            
                r->bal = 1;
                *aumentou_altura = 1;
            }

            else if(r->bal == 1){//Caso 4:inseriu no lado mais alto
            
                if(r->dir->bal == -1){//inseriu a esquerda do filho direito

                    //Rotação direita esquerda
                    r->dir = rotacaoDir(r->dir);
                    r = rotacaoEsq(r);


                    if(r->bal == 0){
                        r->esq->bal = 0;
                        r->dir->bal = 0;
                    }

                    else if(r->bal == -1){

                        r->esq->bal = 1;
                        r->dir->bal = 0;
                    }

                    else{//r->bal == 1
                    
                    
                        r->esq->bal = 0;
                        r->dir->bal = -1;
                    }

                }

                else{//r->dir->bal == 1, inseriu a direita do filho direito
                
                     //Rotação a esquerda
                    r = rotacaoEsq(r);
                   
                   r->esq->bal = 0;

                }

                r->bal = 0;
                *aumentou_altura = 0;
            }
        }
    }

    return r;
//FIM DA FUNÇÃO    
}

Arvore inserir(Arvore r,Chave chave,Cont conteudo){

    int aumentou_altura;
    Noh *novo = novoNOH(chave,conteudo);
    return insereAVL(r,novo,&aumentou_altura);

}

void em_ordem(Arvore r){

    if(r != NULL){

        em_ordem(r->esq);
        printf("{%d,%d}\n",r->chave,r->conteudo);
        em_ordem(r->dir);
    }

    return;
}

void pre_ordem(Arvore r){

    if(r != NULL){

        printf("{%d,%d}\n",r->chave,r->conteudo);
        pre_ordem(r->esq);
        pre_ordem(r->dir);
    }

    return;
}


void pos_ordem(Arvore r){

    if(r != NULL){

        pos_ordem(r->esq);
        pos_ordem(r->dir);
                printf("{%d,%d}\n",r->chave,r->conteudo);

    }

    return;
}

int alturaAR(Arvore r){

    if(r== NULL) return -1;

    int hesq,hdir;

    hesq = alturaAR(r->esq);
    hdir = alturaAR(r->dir);

    if(hesq > hdir)
        return hesq+1;
    return hdir +1;
}

int verifica(Arvore r){

    int hesq = alturaAR(r->esq);
    int hdir = alturaAR(r->dir);

    if(abs(hesq-hdir) <= 1)
        return TRUE;
    return FALSE;
}

Noh* busca(Arvore r,Chave chave){

    if(r == NULL) return r;

    if(chave < r->chave)
        return busca(r->esq,chave);
    if(chave == r->chave)
        return r;
    return busca(r->dir, chave);
}

Noh* maxAVL(Arvore r){

    if(r->dir == NULL)
        return r;
    return maxAVL(r->dir);
}


Arvore removeAVL(Arvore r,Arvore alvo,int *diminuiu_tamanho){

    Arvore aux,p;

    //Caso 1
    if(alvo->esq == NULL && alvo->dir == NULL){

        if(r != NULL){

            

            if(r->conteudo >= alvo->conteudo){//alvo esta a esquerda de seu pai
            
                if(r->bal == -1){//removeu do maior lado 

                    r->bal = 0;
                    *diminuiu_tamanho = 1;
                }

                else if(r->bal == 0){//alturas eram iguais
                
                    r->bal = +1;
                    *diminuiu_tamanho = 0;
                }

                else{//if alvo->pai->bal == +1, removeu do menor lado
                    
                    r = rotacaoEsq(r);
                    r->esq->bal = 0;
                    *diminuiu_tamanho = 1;
                }
            
            }
            else{//alvo estaa direita de seu pai

                if(r->bal == +1){//removeu do maior lado

                    r->bal = 0;
                    *diminuiu_tamanho = 1;
                }

                else if(r->bal == 0){//o pai tinha duas subarvores iguais
                
                    r->bal = -1;
                    *diminuiu_tamanho = 0;
                }

                else{

                    r = rotacaoDir(r);
                    r->dir->bal = 0;
                    *diminuiu_tamanho = 1;
                }

            }
        }



        else    *diminuiu_tamanho = 1;
        
       
        free(alvo);
        return NULL;
    }

    //Caso 2
    if(alvo->esq == NULL || alvo->dir == NULL){

        if(alvo->esq == NULL)
            aux = alvo->dir;
        
        else
            aux = alvo->esq;
        
        aux->pai = alvo->pai;
        free(alvo);
        return aux;
    }

    //Caso 3
    aux = maxAVL(alvo->esq);
    alvo->chave = aux->chave;
    alvo->conteudo = aux->conteudo;
    p = aux->pai;

    if(p == alvo){
        p->esq = removeAVL(r,aux,diminuiu_tamanho);
    }
    else
        p->dir = removeAVL(r,aux,diminuiu_tamanho);

    return alvo;
}


Arvore TSremove(Arvore tab, Chave chave){

    Arvore aux,p,alvo;
    alvo = busca(tab,chave); 

    if(alvo == NULL) return tab;    

    int diminuiu_tamanho;
    p = alvo->pai;
    aux = removeAVL(p,alvo,&diminuiu_tamanho); 

    if(p == NULL){
        tab = aux;
        return tab;
    }   
  
    if(p->esq == alvo)
        p->esq = aux;

    if(p->dir == alvo)
        p->dir = aux;

    return aux;
}

